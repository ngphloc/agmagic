using System;
using System.Data;
using System.Data.OleDb;

namespace kt3t
{
	/// <summary>
	/// Summary description for DataService.
	/// </summary>
	public class DataService
	{
		// The connection to a database of this data service.
		private IDbConnection	_connection;

		// The command to execute query or non-query command on a database of this data service.
		private IDbCommand		_command;

		// The data adapter to execute query on a database of this data service.
		private IDbDataAdapter	_dataAdapter;

		public DataService()
		{
			_connection = new OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0; Data Source=kt3t.mdb");

			_command = new OleDbCommand();
			_command.Connection = _connection;

			_dataAdapter = new OleDbDataAdapter();
			_dataAdapter.SelectCommand = _command;
		}

		/// <summary>
		/// Opens the connection of this data service.
		/// </summary>
		public void openConnection()
		{
			// Opens the connection if it is closed.
			if (_connection.State == ConnectionState.Closed)
				_connection.Open();
		}

		/// <summary>
		/// Closes the connection of this data service.
		/// </summary>
		public void closeConnection()
		{
			_connection.Close();
		}

		/// <summary>
		/// Gets a data set from executing the specified query string.
		/// </summary>
		/// <param name="queryString">The query string specified.</param>
		/// <returns>The data set.</returns>
		public DataSet executeQuery(string queryString)
		{
			try
			{
				DataSet	ds = new DataSet();

				_command.CommandText = queryString;
				_command.CommandType = CommandType.Text;
				_dataAdapter.Fill(ds);

				return ds;
			}
			catch { throw; }
		}

		/// <summary>
		/// Executes the specified DML string on the database.
		/// </summary>
		/// <param name="dmlString">The DML string specified.</param>
		public void executeDML(string dmlString)
		{
			try
			{
				openConnection();
				_command.CommandText = dmlString;
				_command.CommandType = CommandType.Text;
				_command.ExecuteNonQuery();
			}
			catch { throw; }
			finally
			{
				// Closes the connection if there is no transaction.
				if (_command.Transaction == null)
					closeConnection();
			}
		}
	}
}