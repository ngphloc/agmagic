using System;
using System.Data;

namespace kt3t
{
	/// <summary>
	/// Summary description for PublisherList.
	/// </summary>
	public class PublisherList
	{
		private DataService	_ds;

		public PublisherList()
		{
			_ds = new DataService();
		}

		public DataTable getPublisherList()
		{
			return _ds.executeQuery("select id_publisher, publisher_name from Publisher").Tables[0];
		}
	}
}
