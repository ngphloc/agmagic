using System;
using System.Data;

namespace kt3t
{
	/// <summary>
	/// Summary description for AuthorList.
	/// </summary>
	public class AuthorList
	{
		private DataService	_ds;

		public AuthorList()
		{
			 _ds = new DataService();
		}

		public DataTable getAurthorList()
		{
			return _ds.executeQuery("select id_author, author_name from Author").Tables[0];
		}
	}
}
