using System;
using System.Data;

namespace kt3t
{
	/// <summary>
	/// Summary description for BookList.
	/// </summary>
	public class BookList
	{
		private DataService	_ds;

		public BookList()
		{
			_ds = new DataService();
		}

		public DataTable getBookList()
		{
			return _ds.executeQuery("select id_book, title from Book").Tables[0];
		}
	}
}
