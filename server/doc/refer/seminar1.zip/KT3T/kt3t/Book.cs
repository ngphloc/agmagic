using System;
using System.Data;

namespace kt3t
{
	/// <summary>
	/// Summary description for Book.
	/// </summary>
	public class Book
	{
		private DataService	_ds;
		private bool		_isNew;

		private int		_id_book;
		private string	_title;
		private int		_id_author;
		private int		_id_publisher;
		private int		_publish_year;

		public int IDBook
		{
			get { return _id_book; }
		}

		public string Title
		{
			get { return _title; }
			set { _title = value; }
		}

		public int IDAuthor
		{
			get { return _id_author; }
			set { _id_author = value; }
		}

		public int IDPublisher
		{
			get { return _id_publisher; }
			set { _id_publisher = value; }
		}

		public int PublishYear
		{
			get { return _publish_year; }
			set { _publish_year = value; }
		}

		public Book()
		{
			_ds = new DataService();
			_isNew = true;

			_title = "";
			_id_author = 0;
			_id_publisher = 0;
			_publish_year = DateTime.Now.Year;
		}

		public Book(int idBook)
		{
			_ds = new DataService();
			_isNew = false;

			DataRow	row = _ds.executeQuery("select * from Book where id_book = " + idBook).Tables[0].Rows[0];

			_id_book = (int)row["id_book"];
			_title = (string)row["title"];
			_id_author = (int)row["id_author"];
			_id_publisher = (int)row["id_publisher"];
			_publish_year = (int)row["publish_year"];
		}

		public void update()
		{
			string	dmlString;

			if (_isNew)
				dmlString =
					"insert into book(title, id_author, id_publisher, publish_year) " +
					"values('" +
						_title + "', " +
						_id_author + ", " +
						_id_publisher + ", " +
						_publish_year + ")";
			else
				dmlString =
					"update book " +
					"set " +
						"title = '" + _title + "', " +
						"id_author = " + _id_author + ", " +
						"id_publisher = " + _id_publisher + ", " +
						"publish_year = " + _publish_year + " " +
					"where id_book = " + _id_book;

			_ds.executeDML(dmlString);
		}
	}
}